---
agent: speckit.plan
---
